'use strict';

/* Controllers */

angular.module('app')
    .controller('HomeCtrl', ['$scope', function($scope) {

    	$scope.message = "How are you doing today?";

    }]);
